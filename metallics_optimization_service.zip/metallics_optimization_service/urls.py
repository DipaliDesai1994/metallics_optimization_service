from django.conf.urls import url, include
from tnmsc.views import get_all_chemical_elements, get_commodity_by_id, update_commodity_by_id, add_chemical_concentration, remove_chemical_concentration

urlpatterns = [url(r'^get_all_chemical_elements/(?P<username>[\w-]+)/(?P<password>[\w-]+)/',get_all_chemical_elements,name="get_all_chemical_elements"),
               url(r'^get_commodity_by_id/(?P<username>[\w-]+)/(?P<password>[\w-]+)/(?P<commodity_id>[\w-]+)/',get_commodity_by_id,name="get_commodity_by_id"),
               url(r'^update_commodity_by_id/(?P<username>[\w-]+)/(?P<password>[\w-]+)/(?P<commodity_id>[\w-]+)/(?P<commodity_name>[\w-]+)/(?P<commodity_price>[\w-]+)/',
                   update_commodity_by_id,name="update_commodity_by_id"),
               url(r'^add_chemical_concentration/(?P<username>[\w-]+)/(?P<password>[\w-]+)/(?P<commodity_id>[\w-]+)/(?P<element_id>[\w-]+)/(?P<percentage>[\w-]+)/',
                   add_chemical_concentration,name="add_chemical_concentration"),
               url(r'^remove_chemical_concentration/(?P<username>[\w-]+)/(?P<password>[\w-]+)/(?P<commodity_id>[\w-]+)/(?P<element_id>[\w-]+)/',
                   remove_chemical_concentration,name="remove_chemical_concentration"
              ]
