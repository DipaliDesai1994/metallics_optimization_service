1. Install python 3.5+ version and required modules using pip 
   e.g : pip install django
2. Install SQL dependencies and server and create schema using mettalic_optimization_service.sql file
3. Run the server
4. Access the endpoints