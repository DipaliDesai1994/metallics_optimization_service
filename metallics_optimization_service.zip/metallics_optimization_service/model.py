from django.db import models

# Create your models here.
class Chemical_element(models.Model):
    id=models.IntegerField(default=None)
    name=models.CharField(max_length=64,default=None)
        
    class Meta:
      db_table = "Chemical_element"
      
class Commodity(models.Model):
    id=models.IntegerField(default=None)
    name=models.CharField(max_length=64,default=None)
    inventory=models.CharField(max_length=64,default=None)
    price=models.FloatField(null=True)
    chemical_composition=models.CharField(max_length=255,default=None)
    
    class Meta:
      db_table = "Commodity"      

        

    
    
