#!C:\Python25 Python
import shutil

import win32serviceutil
import win32service
import win32event
import win32api
import win32process
import os
import sys
import subprocess
import xml.etree.ElementTree as ET
import simplejson as json
import atexit
import time
import readConf
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
confPath=os.path.join(BASE_DIR,'config.xml')
confObj=readConf.readConf()
serviceIP=confObj.getValue(confPath,'IP')
servicePort=confObj.getValue(confPath,'Port')

#TODO: find better way to set python.exe
_python_excutable = "C:\\Python27\\python.exe"
_python_excutable_dashboard_server = "C:\\Python27\\python-metallics_optimization_service.exe"
if not os.path.exists(_python_excutable_dashboard_server):
    shutil.copy(_python_excutable,_python_excutable_dashboard_server)

current_dir = os.path.split(__file__)[0]

#----------------------------------- SETTING THE LOG OBJECT
class InstaWebSupervisorService(win32serviceutil.ServiceFramework):
    _svc_name_ = "metallics_optimization_service"
    _svc_display_name_ = "metallics_optimization_service"
    _svc_description_ = "This Service is used to display metallics optimization service data."
    
    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        self.dashboard_process_id = {}
       
    
    

    def SvcDoRun(self):
       
        serverIp = serviceIP
        serverPort = servicePort
        # Starting dashboards here
        startupInfo1 = win32process.STARTUPINFO()
        processPath1 = os.path.join(_python_excutable_dashboard_server+" "+os.path.join(current_dir,"manage.py")+" runserver "+str(serverIp)+":"+str(serverPort))
        processDetails1 = win32process.CreateProcess(None,processPath1,None, None, False, 0, None, None, startupInfo1)
        win32event.WaitForSingleObject(self.stop_event, win32event.INFINITE)
        
    def SvcStop(self):
       
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        subprocess.call(['taskkill', '/F', '/T', '/IM', 'python-metallics_optimization_service.exe'])
        win32event.SetEvent(self.stop_event)
    
    def TerminateProcess(self, pid):
        try:
            PROCESS_TERMINATE = 1
            handle = win32api.OpenProcess(PROCESS_TERMINATE, False, pid)
            win32api.TerminateProcess(handle, -1)
            win32api.CloseHandle(handle)
        except Exception,e:
           raise
        
if __name__ == '__main__':
    win32serviceutil.HandleCommandLine(InstaWebSupervisorService)
