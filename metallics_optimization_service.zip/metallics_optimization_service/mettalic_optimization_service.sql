create table auth_data.credentials
(
   id INTEGER AUTO_INCREMENT PRIMARY KEY NOT NULL, 
   username VARCHAR(70),
   password VARCHAR(70)
);



CREATE TABLE Chemical_element (
   id int NOT NULL PRIMARY KEY,
   name varchar(255) NOT NULL,
);

CREATE TABLE Commodity (
    id int NOT NULL PRIMARY KEY,
    name varchar(255) NOT NULL,
    inventory VARCHAR(64),
    price FLOAT(16) DEFAULT 0.0,
    chemical_composition VARCHAR(255),
);


INSERT INTO Chemical_element (id, name) VALUES (6, 'C');
INSERT INTO Chemical_element (id, name) VALUES (7, 'N');
INSERT INTO Chemical_element (id, name) VALUES (8, 'O');
INSERT INTO Chemical_element (id, name) VALUES (13, 'AI');
INSERT INTO Chemical_element (id, name) VALUES (26, 'Fe');
INSERT INTO Chemical_element (id, name) VALUES (29, 'Cu');
INSERT INTO Chemical_element (id, name) VALUES (9999, 'Unknown');

INSERT INTO Commodity (id, name,inventory, price, chemical_composition ) VALUES (42, Plate & Structural', 1234.50, 200.5, "13:20, 26:50, 29:10, 9999:15");

insert into credentials (username,password) VALUES ('admin','admin');