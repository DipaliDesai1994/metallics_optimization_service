import xml.etree.ElementTree as etree


class readConf:
    
    def __init__(self):
        pass
    
    def getValue(self,filename=None,tags=None):
       
        tree = etree.parse(filename)
        root = tree.getroot()
        var=(root.find(tags).text)
        return (var)
        




