from django.http import HttpResponse,JsonResponse
from django.http import HttpResponseRedirect
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view
from model import Chemical_element, Commodity
from model import credentials

@csrf_exempt
@api_view(['GET'])
def get_all_chemical_elements(request):
    username=str(request.GET['username'])
    password=str(request.GET['password'])
    authentication_result = authenticate(username, password)
    if authentication_result:
        chemical_elements=Chemical_element.objects.values('id,name').all()
        for chemical_element in chemical_elements:
            data = {}
            data["id"]=chemical_element['id']
            data["name"]=chemical_element['name']
            result_list.append(data)    
        return HttpResponse(result_list)
    else:
        return HttpResponse({"message":"Invalid Credentials"}) 

@csrf_exempt
@api_view(['GET'])
def get_commodity_by_id(request):
    commodity_id=request.GET['commodity_id']
    commodity_id=str(commodity_id)
    username=str(request.GET['username'])
    password=str(request.GET['password'])
    authentication_result = authenticate(username, password)
    if authentication_result:
        commodities=Commodity.objects.values('id,name,inventory,price,chemical_composition').filter(id=commodity_id).all()
        for commodity in commodities:
            data = {}
            composition_element_list = []
            data["id"]=commodity['id']
            data["name"]=commodity['name']
            data["inventory"]=commodity['inventory']
            data["price"]=commodity['price']
            composition=commodity['chemical_composition']
            composition_list=composition.split(",")
            for comp in composition_list:
                dict = {}
                comp.split(":")
                element_id = comp[0]
                chemical_elements=Chemical_element.objects.values('id,name').filter(id=element_id).all()
                for chemical_element in chemical_elements:
                    element = {}
                    element["id"]=chemical_element['id']
                    element["name"]=chemical_element['name']
                    dict["element"]=element
                    dict["percentage"]=comp[1]
                    composition_element_list.append(dict)
            data["chemical_composition"]=composition_element_list
            result_list.append(data)    
        return HttpResponse(result_list)
    else:
        return HttpResponse({"message":"Invalid Credentials"})

@csrf_exempt
@api_view(['PUT'])
def update_commodity_by_id(request):
    username=str(request.GET['username'])
    password=str(request.GET['password'])
    authentication_result = authenticate(username, password)
    if authentication_result:
        commodity_id=str(request.GET['commodity_id'])
        commodity_name=str(request.GET['commodity_name'])
        commodity_price=str(request.GET['commodity_price'])
        result = Commodity.objects.filter(id=commodity_id).update(name=commodity_name,price=commodity_price)
        if result:
            return HttpResponse("Successfully updated...")
        else:
            return HttpResponse("Upade Failed...")
    else:
        return HttpResponse({"message":"Invalid Credentials"})
@csrf_exempt
@api_view(['POST'])
def add_chemical_concentration(request):
    username=str(request.GET['username'])
    password=str(request.GET['password'])
    authentication_result = authenticate(username, password)
    if authentication_result:
        commodity_id=str(request.GET['commodity_id'])
        element_id=str(request.GET['element_id'])
        percentage=str(request.GET['percentage'])
        result = Commodity.objects.values('chemical_composition').filter(id=commodity_id).first()
        if result:
            chemical_composition = result.chemical_composition
            chemical_composition.append(","+element_id+":"+percentage+"")
            add_result = Commodity.objects.filter(id=commodity_id).add(chemical_composition=chemical_composition)
        if add_result:
            return HttpResponse("Successfully chemical_concentration aded...")
        else:
            return HttpResponse("Adding chemical_concentration Failed...")
    else:
        return HttpResponse({"message":"Invalid Credentials"})

@csrf_exempt
@api_view(['DELETE'])
def remove_chemical_concentration(request):
    username=str(request.GET['username'])
    password=str(request.GET['password'])
    authentication_result = authenticate(username, password)
    if authentication_result:
        commodity_id=str(request.GET['commodity_id'])
        element_id=str(request.GET['element_id'])
        result = Commodity.objects.values('chemical_composition').filter(id=commodity_id).first()
        if result:
            chemical_composition = result.chemical_composition
            chemical_composition_list = chemical_composition.split(",")
            chemical_composition_list.remove('element_id')
            chemical_composition = str(chemical_composition_list)
            add_result = Commodity.objects.filter(id=commodity_id).add(chemical_composition=chemical_composition)
        if add_result:
            return HttpResponse("Successfully chemical_concentration removed...")
        else:
            return HttpResponse("Removing chemical_concentration Failed...")
    else:
        return HttpResponse({"message":"Invalid Credentials"})

def authenticate(username,password):
    credentialsObj= credentials.objects.values('username','password').filter(username=username,password=password).first()
    if credentialsObj:
        return True
    else:
        return False
